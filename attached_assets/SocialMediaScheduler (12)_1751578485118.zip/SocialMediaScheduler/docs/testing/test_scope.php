<?php
$scope = "pages_read_engagement,pages_read_user_content,public_profile,email";
?>

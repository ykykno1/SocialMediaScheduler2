import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Clock, Settings, Crown, Calendar, MapPin } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface TimingPreferences {
  hideTimingPreference: 'immediate' | '15min' | '30min' | '1hour';
  restoreTimingPreference: 'immediate' | '30min' | '1hour';
}

interface User {
  id: string;
  email: string;
  accountType: 'free' | 'youtube_pro' | 'premium';
  hideTimingPreference?: string;
  restoreTimingPreference?: string;
}

export default function TimingSettingsPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [hidePreference, setHidePreference] = useState<'immediate' | '15min' | '30min' | '1hour'>('1hour');
  const [restorePreference, setRestorePreference] = useState<'immediate' | '30min' | '1hour'>('immediate');
  
  // Admin manual date/time settings
  const [adminEntryDate, setAdminEntryDate] = useState('');
  const [adminEntryTime, setAdminEntryTime] = useState('');
  const [adminExitDate, setAdminExitDate] = useState('');
  const [adminExitTime, setAdminExitTime] = useState('');

  // Get current user data
  const { data: user, isLoading: userLoading } = useQuery<User>({
    queryKey: ['/api/user'],
  });

  // Get user's location data
  const { data: locationData } = useQuery<{shabbatCity: string; shabbatCityId: string}>({
    queryKey: ['/api/user/shabbat-location'],
  });

  // Load current preferences
  useEffect(() => {
    if (user) {
      setHidePreference((user.hideTimingPreference as any) || '1hour');
      setRestorePreference((user.restoreTimingPreference as any) || 'immediate');
    }
  }, [user]);

  // Save timing preferences
  const savePreferencesMutation = useMutation({
    mutationFn: async (preferences: any) => {
      console.log('Sending preferences:', preferences);
      const response = await apiRequest('POST', '/api/user/timing-preferences', preferences);
      console.log('Response:', response);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "הצלחה!",
        description: "העדפות התזמון נשמרו בהצלחה",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/user'] });
      // Also invalidate admin times if it's admin location
      if (locationData && locationData.shabbatCity === 'מנהל') {
        queryClient.invalidateQueries({ queryKey: ['/api/admin/shabbat-times'] });
      }
    },
    onError: (error) => {
      console.error('Save error:', error);
      toast({
        title: "שגיאה",
        description: "שגיאה בשמירת העדפות התזמון",
        variant: "destructive"
      });
    }
  });

  const handleSave = () => {
    const preferences: any = {
      hideTimingPreference: hidePreference,
      restoreTimingPreference: restorePreference
    };

    // Add admin manual times if location is "מנהל"
    if (locationData && locationData.shabbatCity === 'מנהל') {
      preferences.adminEntryDateTime = adminEntryDate && adminEntryTime ? `${adminEntryDate}T${adminEntryTime}:00` : null;
      preferences.adminExitDateTime = adminExitDate && adminExitTime ? `${adminExitDate}T${adminExitTime}:00` : null;
    }

    savePreferencesMutation.mutate(preferences);
  };

  const getTimingLabel = (value: string, type: 'hide' | 'restore') => {
    switch (value) {
      case 'immediate':
        return type === 'hide' ? 'מיד כשמתחיל השבת' : 'מיד כשנגמר השבת';
      case '15min':
        return '15 דקות לפני כניסת שבת';
      case '30min':
        return type === 'hide' ? '30 דקות לפני כניסת שבת' : '30 דקות אחרי צאת השבת';
      case '1hour':
        return type === 'hide' ? 'שעה לפני כניסת שבת' : 'שעה אחרי צאת השבת';
      default:
        return value;
    }
  };

  if (userLoading) {
    return (
      <div className="container mx-auto p-6 max-w-4xl">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/3 mb-4"></div>
          <div className="h-64 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  // Check if user is premium - temporarily disabled for testing
  const isPremium = true; // user?.accountType === 'premium';

  if (!isPremium) {
    return (
      <div className="container mx-auto p-6 max-w-4xl">
        <div className="mb-6">
          <h1 className="text-3xl font-bold mb-2">הגדרות תזמון</h1>
          <p className="text-muted-foreground">
            התאם אישית את זמני ההסתרה והחזרה של תכנים במדיה חברתית
          </p>
        </div>

        <Card className="border-amber-200 bg-amber-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-amber-800">
              <Crown className="h-5 w-5" />
              תכונה לחברי פרמיום בלבד
            </CardTitle>
            <CardDescription className="text-amber-700">
              הגדרות תזמון מותאמות אישית זמינות רק לחברי פרמיום. 
              שדרג את החשבון שלך כדי לגשת לתכונה זו.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button className="bg-amber-600 hover:bg-amber-700">
              שדרג לפרמיום
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 max-w-4xl">
      <div className="mb-6">
        <h1 className="text-3xl font-bold mb-2">הגדרות תזמון מותאמות אישית</h1>
        <p className="text-muted-foreground">
          התאם אישית את זמני ההסתרה והחזרה של תכנים במדיה חברתית לפי השבת
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Current Settings Display */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              הגדרות נוכחיות
            </CardTitle>
            <CardDescription>
              העדפות התזמון הנוכחיות שלך
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-4 bg-red-50 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                <span className="font-medium text-red-900">זמן הסתרת תכנים</span>
              </div>
              <p className="text-red-800">{getTimingLabel(hidePreference, 'hide')}</p>
            </div>
            
            <div className="p-4 bg-green-50 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                <span className="font-medium text-green-900">זמן החזרת תכנים</span>
              </div>
              <p className="text-green-800">{getTimingLabel(restorePreference, 'restore')}</p>
            </div>
          </CardContent>
        </Card>

        {/* Timing Configuration */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="h-5 w-5" />
              קביעת זמנים חדשים
            </CardTitle>
            <CardDescription>
              בחר את הזמנים המועדפים עליך להסתרה והחזרה
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-3">
              <Label htmlFor="hide-timing">זמן הסתרת תכנים</Label>
              <Select value={hidePreference} onValueChange={(value: any) => setHidePreference(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="immediate">מיד כשמתחיל השבת</SelectItem>
                  <SelectItem value="15min">15 דקות לפני כניסת שבת</SelectItem>
                  <SelectItem value="30min">30 דקות לפני כניסת שבת</SelectItem>
                  <SelectItem value="1hour">שעה לפני כניסת שבת (מומלץ)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-3">
              <Label htmlFor="restore-timing">זמן החזרת תכנים</Label>
              <Select value={restorePreference} onValueChange={(value: any) => setRestorePreference(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="immediate">מיד כשנגמר השבת (מומלץ)</SelectItem>
                  <SelectItem value="30min">30 דקות אחרי צאת השבת</SelectItem>
                  <SelectItem value="1hour">שעה אחרי צאת השבת</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Admin Manual Date/Time Settings */}
            {locationData && locationData.shabbatCity === 'מנהל' && (
              <Card className="border-dashed border-2 border-amber-300 bg-amber-50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-amber-800">
                    <Calendar className="h-5 w-5" />
                    <MapPin className="h-5 w-5" />
                    הגדרות זמן ידניות למנהל
                  </CardTitle>
                  <CardDescription className="text-amber-700">
                    בחר תאריכים ושעות מדויקות לכניסת ויציאת השבת
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Entry Date/Time */}
                    <div className="space-y-2">
                      <Label className="text-red-800 font-medium">כניסת שבת</Label>
                      <div className="space-y-2">
                        <Input
                          type="date"
                          value={adminEntryDate}
                          onChange={(e) => setAdminEntryDate(e.target.value)}
                          className="text-right"
                        />
                        <Input
                          type="time"
                          value={adminEntryTime}
                          onChange={(e) => setAdminEntryTime(e.target.value)}
                          className="text-right"
                        />
                      </div>
                    </div>

                    {/* Exit Date/Time */}
                    <div className="space-y-2">
                      <Label className="text-green-800 font-medium">יציאת שבת</Label>
                      <div className="space-y-2">
                        <Input
                          type="date"
                          value={adminExitDate}
                          onChange={(e) => setAdminExitDate(e.target.value)}
                          className="text-right"
                        />
                        <Input
                          type="time"
                          value={adminExitTime}
                          onChange={(e) => setAdminExitTime(e.target.value)}
                          className="text-right"
                        />
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-sm text-amber-700 bg-amber-100 p-3 rounded-lg">
                    <strong>הערה:</strong> כשהמיקום מוגדר כ"מנהל", המערכת תשתמש בתאריכים ובשעות שבחרת כאן 
                    במקום לחשב אוטומטית לפי מיקום גיאוגרפי.
                  </div>
                </CardContent>
              </Card>
            )}

            <Button 
              onClick={handleSave}
              disabled={savePreferencesMutation.isPending}
              className="w-full"
            >
              {savePreferencesMutation.isPending ? "שומר..." : "שמור הגדרות"}
            </Button>

            <div className="text-sm text-muted-foreground bg-blue-50 p-3 rounded-lg">
              <strong>הסבר:</strong> הגדרות אלו יחולו על כל הפלטפורמות המחוברות שלך 
              (פייסבוק, יוטיוב וכו'). המערכת תפעל אוטומטית לפי הזמנים שבחרת.
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="mt-6">
        <CardHeader>
          <CardTitle>דוגמאות לתזמון</CardTitle>
          <CardDescription>
            הבן כיצד יפעלו ההגדרות שלך בפועל
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="p-4 border rounded-lg">
              <h4 className="font-medium mb-2">🕯️ שבת זה השבוע</h4>
              <p className="text-sm text-muted-foreground mb-2">כניסת שבת: יום ו' 19:15</p>
              <p className="text-sm text-muted-foreground mb-2">צאת השבת: יום ש' 20:30</p>
              <div className="text-sm">
                <div className="text-red-600">• הסתרה: {
                  hidePreference === 'immediate' ? 'יום ו\' 19:15' :
                  hidePreference === '15min' ? 'יום ו\' 19:00' :
                  hidePreference === '30min' ? 'יום ו\' 18:45' :
                  'יום ו\' 18:15'
                }</div>
                <div className="text-green-600">• החזרה: {
                  restorePreference === 'immediate' ? 'יום ש\' 20:30' :
                  restorePreference === '30min' ? 'יום ש\' 21:00' :
                  'יום ש\' 21:30'
                }</div>
              </div>
            </div>
            
            <div className="p-4 border rounded-lg">
              <h4 className="font-medium mb-2">📱 מה יקרה?</h4>
              <ul className="text-sm space-y-1">
                <li>• פוסטים בפייסבוק יוסתרו</li>
                <li>• סרטונים ביוטיוב יהפכו לפרטיים</li>
                <li>• התכנים יחזרו אוטומטית</li>
                <li>• תקבל התראות על הפעולות</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}